function varargout = PerceptronRule(varargin)
% PERCEPTRONRULE MATLAB code for PerceptronRule.fig
%      PERCEPTRONRULE, by itself, creates a new PERCEPTRONRULE or raises the existing
%      singleton*.
%
%      H = PERCEPTRONRULE returns the handle to a new PERCEPTRONRULE or the handle to
%      the existing singleton*.
%
%      PERCEPTRONRULE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PERCEPTRONRULE.M with the given input arguments.
%
%      PERCEPTRONRULE('Property','Value',...) creates a new PERCEPTRONRULE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PerceptronRule_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PerceptronRule_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PerceptronRule

% Last Modified by GUIDE v2.5 23-Sep-2018 09:52:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PerceptronRule_OpeningFcn, ...
                   'gui_OutputFcn',  @PerceptronRule_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PerceptronRule is made visible.
function PerceptronRule_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PerceptronRule (see VARARGIN)

% Choose default command line output for PerceptronRule
handles.output = hObject;

if (get(handles.radiobuttonSTEP,'Value')) 
    set(handles.editP1C,'Value',0);
    set(handles.editP2C,'Value',0);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
else
    set(handles.editP1C,'Value',-1);
    set(handles.editP2C,'Value',-1);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
end

axes(handles.axes1); hold on;
axis([-5 5 -5 5]);
xlabel('x1');ylabel('x2');
p1x = str2num(get(handles.editP1X,'String'));
p1y = str2num(get(handles.editP1Y,'String'));

p1 = plot(p1x,p1y,'g*');set(p1,'visible','on','markersize',8);
handles.p1 = p1;

p2x = str2num(get(handles.editP2X,'String'));
p2y = str2num(get(handles.editP2Y,'String'));

p2 = plot(p2x,p2y,'g*');set(p2,'visible','on','markersize',8);
handles.p2 = p2;

p3x = str2num(get(handles.editP3X,'String'));
p3y = str2num(get(handles.editP3Y,'String'));

p3 = plot(p3x,p3y,'r*');set(p3,'visible','on','markersize',8);
handles.p3 = p3;

p4x = str2num(get(handles.editP4X,'String'));
p4y = str2num(get(handles.editP4Y,'String'));

p4 = plot(p4x,p4y,'r*');set(p4,'visible','on','markersize',8);
handles.p4 = p4;

w1 = str2num(get(handles.editW1,'String'));
w2 = str2num(get(handles.editW2,'String'));
T = str2num(get(handles.editT,'String'));

handles.h = -5:0.1:5;
handles.y = (T-w1*handles.h)/w2;
% m1 = w(1,2)/w(1,3)
% ic1 = w(1,1)/w(1,3)
handles.pC = plot(handles.h,handles.y,'b-.');
C1 = get(handles.editP1C,'Value');
C2 = get(handles.editP2C,'Value');
C3 = get(handles.editP3C,'Value');
C4 = get(handles.editP4C,'Value');
Ut = [C1 C2 C3 C4]';

W = [w1 w2 T];
PP = [p1x p1y -1;...
      p2x p2y -1;...
      p3x p3y -1;...
      p4x p4y -1];
  
if (get(handles.radiobuttonSTEP,'Value'))
    U = heaviside(PP * W');
else
    U = sign(PP * W');
    ii = find(U==0); 
    if (isempty(ii)==0) 
        U(ii) = -1;
    end
end

delta = Ut-U;

currClassP1 = dot([w1 w2 T],[p1x p1y -1]);
currClassP2 = dot([w1 w2 T],[p2x p2y -1]);
currClassP3 = dot([w1 w2 T],[p3x p3y -1]);
currClassP4 = dot([w1 w2 T],[p4x p4y -1]);
 
if (currClassP1<0)
    handles.p1Curr =  plot(p1x,p1y,'go');
else
    handles.p1Curr =  plot(p1x,p1y,'ro');
end
set(handles.p1Curr,'visible','on','markersize',12);

if (currClassP2<0)
    handles.p2Curr =  plot(p2x,p2y,'go');
else
    handles.p2Curr =  plot(p2x,p2y,'ro');
end
set(handles.p2Curr,'visible','on','markersize',12);

if (currClassP3<0)
    handles.p3Curr =  plot(p3x,p3y,'go');
else
    handles.p3Curr =  plot(p3x,p3y,'ro');
end
set(handles.p3Curr,'visible','on','markersize',12);

if (currClassP4<0)
    handles.p4Curr =  plot(p4x,p4y,'go');
else
    handles.p4Curr =  plot(p4x,p4y,'ro');
end
set(handles.p4Curr,'visible','on','markersize',12);

drawnow;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PerceptronRule wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PerceptronRule_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function editP1X_Callback(hObject, eventdata, handles)
% hObject    handle to editP1X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP1X as text
%        str2double(get(hObject,'String')) returns contents of editP1X as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function editP1X_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP1X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP1Y_Callback(hObject, eventdata, handles)
% hObject    handle to editP1Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP1Y as text
%        str2double(get(hObject,'String')) returns contents of editP1Y as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP1Y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP1Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP1C_Callback(hObject, eventdata, handles)
% hObject    handle to editP1C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP1C as text
%        str2double(get(hObject,'String')) returns contents of editP1C as a double


% --- Executes during object creation, after setting all properties.
function editP1C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP1C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP2X_Callback(hObject, eventdata, handles)
% hObject    handle to editP2X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP2X as text
%        str2double(get(hObject,'String')) returns contents of editP2X as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP2X_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP2X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP2Y_Callback(hObject, eventdata, handles)
% hObject    handle to editP2Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP2Y as text
%        str2double(get(hObject,'String')) returns contents of editP2Y as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP2Y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP2Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP2C_Callback(hObject, eventdata, handles)
% hObject    handle to editP2C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP2C as text
%        str2double(get(hObject,'String')) returns contents of editP2C as a double


% --- Executes during object creation, after setting all properties.
function editP2C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP2C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP3X_Callback(hObject, eventdata, handles)
% hObject    handle to editP3X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP3X as text
%        str2double(get(hObject,'String')) returns contents of editP3X as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP3X_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP3X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP3Y_Callback(hObject, eventdata, handles)
% hObject    handle to editP3Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP3Y as text
%        str2double(get(hObject,'String')) returns contents of editP3Y as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP3Y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP3Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP3C_Callback(hObject, eventdata, handles)
% hObject    handle to editP3C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP3C as text
%        str2double(get(hObject,'String')) returns contents of editP3C as a double


% --- Executes during object creation, after setting all properties.
function editP3C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP3C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP4X_Callback(hObject, eventdata, handles)
% hObject    handle to editP4X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP4X as text
%        str2double(get(hObject,'String')) returns contents of editP4X as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP4X_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP4X (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP4Y_Callback(hObject, eventdata, handles)
% hObject    handle to editP4Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP4Y as text
%        str2double(get(hObject,'String')) returns contents of editP4Y as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdatePoints(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editP4Y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP4Y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editP4C_Callback(hObject, eventdata, handles)
% hObject    handle to editP4C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editP4C as text
%        str2double(get(hObject,'String')) returns contents of editP4C as a double


% --- Executes during object creation, after setting all properties.
function editP4C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editP4C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editW1_Callback(hObject, eventdata, handles)
% hObject    handle to editW1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editW1 as text
%        str2double(get(hObject,'String')) returns contents of editW1 as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'))
    if (str2num(val)==0)
        set(hObject,'String','0.1');
    end
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdateBoundary(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function editW1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editW1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editW2_Callback(hObject, eventdata, handles)
% hObject    handle to editW2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editW2 as text
%        str2double(get(hObject,'String')) returns contents of editW2 as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'))
    if (str2num(val)==0)
        set(hObject,'String','0.1');
    end
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdateBoundary(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function editW2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editW2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editT_Callback(hObject, eventdata, handles)
% hObject    handle to editT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editT as text
%        str2double(get(hObject,'String')) returns contents of editT as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
    set(handles.pushbuttonRUN,'enable','on');
    handles = UpdateBoundary(handles);
    handles = UpdateClassification(handles);
else
    set(handles.pushbuttonRUN,'enable','off');
end
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function editT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editLR_Callback(hObject, eventdata, handles)
% hObject    handle to editLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editLR as text
%        str2double(get(hObject,'String')) returns contents of editLR as a double
val = get(hObject,'String');
if all(ismember(val, '0123456789+-.eEdD'));
   if (str2double(val)>1) 
        set(hObject,'String','1');
   end
   if (str2double(val)<0.01) 
        set(hObject,'String','0.01');
   end
else
   set(hObject,'String','1') 
end

% --- Executes during object creation, after setting all properties.
function editLR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbuttonRUN.
function pushbuttonRUN_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonRUN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

C1 = get(handles.editP1C,'Value');
C2 = get(handles.editP2C,'Value');
C3 = get(handles.editP3C,'Value');
C4 = get(handles.editP4C,'Value');

Ut = [C1 C2 C3 C4]';

p1x = str2num(get(handles.editP1X,'String'));
p1y = str2num(get(handles.editP1Y,'String'));
p2x = str2num(get(handles.editP2X,'String'));
p2y = str2num(get(handles.editP2Y,'String'));
p3x = str2num(get(handles.editP3X,'String'));
p3y = str2num(get(handles.editP3Y,'String'));
p4x = str2num(get(handles.editP4X,'String'));
p4y = str2num(get(handles.editP4Y,'String'));

w1 = str2num(get(handles.editW1,'String'));
w2 = str2num(get(handles.editW2,'String'));
T = str2num(get(handles.editT,'String'));

W = [w1 w2 T];
PP = [p1x p1y -1;...
      p2x p2y -1;...
      p3x p3y -1;...
      p4x p4y -1];

if (get(handles.radiobuttonSTEP,'Value'))
    U = heaviside(PP * W');
else
    U = sign(PP * W'); 
    ii = find(U==0); 
    if (isempty(ii)==0) 
        U(ii) = -1;
    end
end

delta = Ut-U;

eta = str2num(get(handles.editLR,'String'));
for i = 1 : 3
    dw(i) = eta * [PP(:,i)]'*delta ;
end
Wn = W + dw;
w1 = Wn(1);
w2 = Wn(2);
T  = Wn(3);

h = get(handles.pC,'xdata');
yn = (T-w1*h)/w2;

set(handles.pC,'ydata',yn);

set(handles.editW1,'String',num2str(Wn(1)));
set(handles.editW2,'String',num2str(Wn(2)));
set(handles.editT,'String',num2str(Wn(3)));

handles = UpdateClassification(handles);

% Update handles structure
guidata(hObject, handles);

% currClassP1 = dot([w1 w2 T],[p1x p1y -1]);
% currClassP2 = dot([w1 w2 T],[p2x p2y -1]);
% currClassP3 = dot([w1 w2 T],[p2x p2y -1]);
% currClassP4 = dot([w1 w2 T],[p2x p2y -1]);

function handles = UpdatePoints(handles)

p1x = str2num(get(handles.editP1X,'String'));
p1y = str2num(get(handles.editP1Y,'String'));
p2x = str2num(get(handles.editP2X,'String'));
p2y = str2num(get(handles.editP2Y,'String'));
p3x = str2num(get(handles.editP3X,'String'));
p3y = str2num(get(handles.editP3Y,'String'));
p4x = str2num(get(handles.editP4X,'String'));
p4y = str2num(get(handles.editP4Y,'String'));
set(handles.p1,'xdata',p1x,'ydata',p1y);
set(handles.p2,'xdata',p2x,'ydata',p2y);
set(handles.p3,'xdata',p3x,'ydata',p3y);
set(handles.p4,'xdata',p4x,'ydata',p4y);
set(handles.p1Curr,'xdata',p1x,'ydata',p1y);
set(handles.p2Curr,'xdata',p2x,'ydata',p2y);
set(handles.p3Curr,'xdata',p3x,'ydata',p3y);
set(handles.p4Curr,'xdata',p4x,'ydata',p4y);

function  handles = UpdateBoundary(handles)
% Get weights
w1 = str2num(get(handles.editW1,'String'));
w2 = str2num(get(handles.editW2,'String'));
T = str2num(get(handles.editT,'String'));
% Update line
h = get(handles.pC,'xdata');
yn = (T-w1*h)/w2;
W = [w1 w2 T];
set(handles.pC,'ydata',yn);


function handles = UpdateClassification(handles)

C1 = get(handles.editP1C,'Value');
C2 = get(handles.editP2C,'Value');
C3 = get(handles.editP3C,'Value');
C4 = get(handles.editP4C,'Value');

Ut = [C1 C2 C3 C4]';

p1x = str2num(get(handles.editP1X,'String'));
p1y = str2num(get(handles.editP1Y,'String'));
p2x = str2num(get(handles.editP2X,'String'));
p2y = str2num(get(handles.editP2Y,'String'));
p3x = str2num(get(handles.editP3X,'String'));
p3y = str2num(get(handles.editP3Y,'String'));
p4x = str2num(get(handles.editP4X,'String'));
p4y = str2num(get(handles.editP4Y,'String'));

w1 = str2num(get(handles.editW1,'String'));
w2 = str2num(get(handles.editW2,'String'));
T = str2num(get(handles.editT,'String'));

W = [w1 w2 T];
PP = [p1x p1y -1;...
      p2x p2y -1;...
      p3x p3y -1;...
      p4x p4y -1];

if (get(handles.radiobuttonSTEP,'Value'))
    U = heaviside(PP * W');
else
    U = sign(PP * W'); 
    ii = find(U==0);
    if (isempty(ii)==0) 
        U(ii) = -1;
    end
end

delta = Ut-U;

currClassP1 = dot([w1 w2 T],[p1x p1y -1]);
currClassP2 = dot([w1 w2 T],[p2x p2y -1]);
currClassP3 = dot([w1 w2 T],[p3x p3y -1]);
currClassP4 = dot([w1 w2 T],[p4x p4y -1]);

if (currClassP1<0)
    set(handles.p1Curr,'color','g'); 
else
    set(handles.p1Curr,'color','r'); 
end


if (currClassP2<0)
    set(handles.p2Curr,'color','g'); 
else
    set(handles.p2Curr,'color','r'); 
end


if (currClassP3<0)
    set(handles.p3Curr,'color','g'); 
else
    set(handles.p3Curr,'color','r'); 
end


if (currClassP4<0)
    set(handles.p4Curr,'color','g'); 
else
    set(handles.p4Curr,'color','r'); 
end

% for i = 1 : 4
%     V = [Ut(i) U(i) ];
%     
%     a(i) = ~any(diff(sign(V(V~=0))))
% 
% end

tTitle = get(handles.axes1,'Title');
if (sum(abs(delta))==0)
    tTitle = get(handles.axes1,'Title');
    tTitle.String = 'Classification Ok';
    set(handles.axes1,'Title',tTitle);
else
    tTitle.String = '';
    set(handles.axes1,'Title',tTitle);
end

drawnow;


% --- Executes on button press in radiobuttonSTEP.
function radiobuttonSTEP_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSTEP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSTEP
if (get(hObject,'Value'))
    set(handles.radiobuttonSIG,'Value',0);
    set(handles.editP1C,'Value',0);
    set(handles.editP2C,'Value',0);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
else
    set(handles.radiobuttonSIG,'Value',1);
    set(handles.editP1C,'Value',-1);
    set(handles.editP2C,'Value',-1);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
end

handles = UpdateClassification(handles);
% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in radiobuttonSIG.
function radiobuttonSIG_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonSIG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonSIG
if (get(hObject,'Value'))
    set(handles.radiobuttonSTEP,'Value',0);
    set(handles.editP1C,'Value',-1);
    set(handles.editP2C,'Value',-1);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
else
    set(handles.radiobuttonSTEP,'Value',1);
    set(handles.editP1C,'Value',0);
    set(handles.editP2C,'Value',0);
    set(handles.editP3C,'Value',1);
    set(handles.editP4C,'Value',1);
end

handles = UpdateClassification(handles);
% Update handles structure
guidata(hObject, handles);
